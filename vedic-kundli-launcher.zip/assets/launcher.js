(function () {
  'use strict';
  var el = document.getElementById('vkl');
  if (!el) return;
  var cfg = window.VKL || {};
  var KEY = 'vkl_hide_until';

  function getHide() {
    var v = 0;
    try { v = parseInt(localStorage.getItem(KEY), 10) || 0; } catch (e) {}
    if (!v) {
      var m = document.cookie.match(/(?:^|; )vkl_hide_until=(\d+)/);
      if (m) v = parseInt(m[1], 10) || 0;
    }
    return v;
  }
  function setHide(ms) {
    var until = Date.now() + ms;
    try { localStorage.setItem(KEY, String(until)); } catch (e) {}
    document.cookie = KEY + '=' + until + ';path=/;max-age=' + Math.floor(ms / 1000) + ';SameSite=Lax';
  }

  if (getHide() > Date.now()) { el.parentNode.removeChild(el); return; }

  var slides = el.querySelectorAll('.vkl__slide');
  var idx = 0, timer = null, paused = false;

  function rotate() {
    if (paused || document.hidden || slides.length < 2) return;
    slides[idx].classList.remove('is-on');
    idx = (idx + 1) % slides.length;
    slides[idx].classList.add('is-on');
  }
  function startRotate() {
    if (!timer && slides.length > 1) timer = setInterval(rotate, cfg.rotate || 3600);
  }

  function show() {
    el.hidden = false;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { el.classList.add('is-visible'); });
    });
    setTimeout(function () { el.classList.add('is-open'); startRotate(); }, 700);
  }

  function close() {
    setHide((cfg.hours || 24) * 3600 * 1000);
    el.classList.remove('is-visible');
    if (timer) clearInterval(timer);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 450);
  }

  el.addEventListener('mouseenter', function () { paused = true; });
  el.addEventListener('mouseleave', function () { paused = false; });
  el.addEventListener('focusin', function () { paused = true; });
  el.addEventListener('focusout', function () { paused = false; });
  el.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  el.querySelector('.vkl__close').addEventListener('click', close);

  setTimeout(show, cfg.delay || 0);
})();
