<?php
/**
 * Plugin Name: Vedic Kundli Launcher (वैदिक कुंडली लॉन्चर)
 * Description: वैदिक जन्म कुंडली टूल को आपकी साइट पर एक पेज के रूप में प्रकाशित करता है और हर पोस्ट व पेज पर एक तैरता हुआ बटन दिखाता है। जो आगंतुक इसे बंद कर देते हैं, उन्हें यह तय समय तक (डिफ़ॉल्ट 24 घंटे) दोबारा नहीं दिखता। पूरा टूल, बटन और सेटिंग्स हिंदी में हैं।
 * Version: 1.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: vedic-kundli-launcher
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VKL_VERSION', '1.1.0' );
define( 'VKL_DIR', plugin_dir_path( __FILE__ ) );
define( 'VKL_URL', plugin_dir_url( __FILE__ ) );

/* ---------------------------------------------------------------
 * Options
 * ------------------------------------------------------------- */

function vkl_defaults() {
	return array(
		'enabled'  => 1,
		'slug'     => 'kundli',
		'title'    => 'मुफ़्त वैदिक जन्म कुंडली रीडिंग',
		'position' => 'right',
		'delay'    => 4,
		'hours'    => 24,
		'logo_url' => '',
		'subline'  => 'मुफ़्त, बिना साइन-अप, बस एक मिनट में तैयार',
		'lines'    => "sparkle|मुफ़्त वैदिक जन्म कुंडली रीडिंग\nheart|आपकी कुंडली प्रेम पर क्या कहती है?\nbriefcase|करियर का सही समय, आसान भाषा में\nclock|जानिए अगले कुछ साल कैसे रहेंगे",
	);
}

function vkl_opts() {
	return wp_parse_args( get_option( 'vkl_options', array() ), vkl_defaults() );
}

function vkl_allowed_icons() {
	return array( 'sparkle', 'heart', 'briefcase', 'clock', 'moon', 'chat' );
}

function vkl_icon( $name ) {
	$p = array(
		'sparkle'   => '<path d="M12 3l1.9 5.4L19.5 10l-5.6 1.7L12 17.5l-1.9-5.8L4.5 10l5.6-1.6z" fill="currentColor" stroke="none"/><path d="M19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z" fill="currentColor" stroke="none"/>',
		'heart'     => '<path d="M12 20s-7.5-4.7-7.5-10.2A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5C19.5 15.3 12 20 12 20z" fill="currentColor" stroke="none"/>',
		'briefcase' => '<rect x="3" y="7.5" width="18" height="12" rx="2.2"/><path d="M9 7.5V5.8A1.8 1.8 0 0 1 10.8 4h2.4A1.8 1.8 0 0 1 15 5.8v1.7M3 13h18"/>',
		'clock'     => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
		'moon'      => '<path d="M20 14.6A8 8 0 0 1 9.4 4 8 8 0 1 0 20 14.6z" fill="currentColor" stroke="none"/>',
		'chat'      => '<path d="M4.5 5.5h15v10.5H10l-4.5 3.5V16h-1z" fill="currentColor" stroke="none"/>',
	);
	$inner = isset( $p[ $name ] ) ? $p[ $name ] : $p['sparkle'];
	return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $inner . '</svg>';
}

function vkl_parse_lines( $raw ) {
	$out     = array();
	$allowed = vkl_allowed_icons();
	$cycle   = $allowed;
	$i       = 0;
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$icon = $cycle[ $i % count( $cycle ) ];
		$text = $line;
		if ( false !== strpos( $line, '|' ) ) {
			list( $maybe, $rest ) = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( in_array( strtolower( $maybe ), $allowed, true ) && '' !== $rest ) {
				$icon = strtolower( $maybe );
				$text = $rest;
			}
		}
		$out[] = array( $icon, mb_substr( $text, 0, 100 ) );
		$i++;
		if ( count( $out ) >= 6 ) {
			break;
		}
	}
	return $out;
}

/* ---------------------------------------------------------------
 * Tool page: create on activation, serve the bundled HTML file
 * ------------------------------------------------------------- */

register_activation_hook( __FILE__, 'vkl_ensure_page' );

function vkl_ensure_page() {
	$id = (int) get_option( 'vkl_page_id' );
	if ( $id && get_post( $id ) && 'trash' !== get_post_status( $id ) ) {
		return $id;
	}
	$o  = vkl_opts();
	$id = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $o['title'],
			'post_name'    => sanitize_title( $o['slug'] ),
			'post_content' => 'यह पेज Vedic Kundli Launcher प्लगइन द्वारा चलाया जाता है। शीर्षक और URL बदलने के लिए सेटिंग्स > कुंडली लॉन्चर में जाएँ।',
		)
	);
	if ( ! is_wp_error( $id ) ) {
		update_option( 'vkl_page_id', $id );
		return $id;
	}
	return 0;
}

add_action( 'admin_init', function () {
	if ( current_user_can( 'manage_options' ) && ! get_option( 'vkl_page_id' ) ) {
		vkl_ensure_page();
	}
} );

function vkl_tool_page_id() {
	return (int) get_option( 'vkl_page_id' );
}

add_action( 'template_redirect', 'vkl_serve_tool', 1 );

function vkl_serve_tool() {
	$id = vkl_tool_page_id();
	if ( ! $id || ! is_page( $id ) ) {
		return;
	}
	$file = VKL_DIR . 'templates/tool.html';
	if ( ! is_readable( $file ) ) {
		return;
	}
	$html   = file_get_contents( $file );
	$canon  = esc_url( get_permalink( $id ) );
	$inject = '<link rel="canonical" href="' . $canon . '">' . "\n" . '<meta property="og:url" content="' . $canon . '">' . "\n";
	$pos    = stripos( $html, '</head>' );
	if ( false !== $pos ) {
		$html = substr_replace( $html, $inject, $pos, 0 );
	}
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- bundled static file.
	exit;
}

/* ---------------------------------------------------------------
 * Upgrade from the English 1.0.0 release: if the saved text is still
 * exactly the old English default, replace it with the Hindi default.
 * Anything the site owner edited by hand is left untouched.
 * ------------------------------------------------------------- */

function vkl_old_english() {
	return array(
		'title'   => 'Free Vedic Birth Chart Reading',
		'subline' => 'Free, no sign-up, ready in a minute',
		'lines'   => "sparkle|Free Vedic birth chart reading\nheart|What does your chart say about love?\nbriefcase|Career timing, decoded\nclock|See what your next few years hold",
		'content' => 'This page is served by the Vedic Kundli Launcher plugin. Edit the title and URL under Settings > Kundli Launcher.',
	);
}

function vkl_norm_nl( $s ) {
	return trim( str_replace( array( "\r\n", "\r" ), "\n", (string) $s ) );
}

add_action( 'admin_init', 'vkl_migrate_to_hindi', 20 );

function vkl_migrate_to_hindi() {
	if ( 'hi' === get_option( 'vkl_lang' ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$old = vkl_old_english();
	$new = vkl_defaults();

	$saved = get_option( 'vkl_options', array() );
	if ( is_array( $saved ) && $saved ) {
		foreach ( array( 'title', 'subline', 'lines' ) as $k ) {
			if ( isset( $saved[ $k ] ) && vkl_norm_nl( $saved[ $k ] ) === $old[ $k ] ) {
				$saved[ $k ] = $new[ $k ];
			}
		}
		update_option( 'vkl_options', $saved );
	}

	$id   = vkl_tool_page_id();
	$post = $id ? get_post( $id ) : null;
	if ( $post ) {
		$upd = array( 'ID' => $id );
		if ( $post->post_title === $old['title'] ) {
			$upd['post_title'] = vkl_opts()['title'];
		}
		if ( $post->post_content === $old['content'] ) {
			$upd['post_content'] = 'यह पेज Vedic Kundli Launcher प्लगइन द्वारा चलाया जाता है। शीर्षक और URL बदलने के लिए सेटिंग्स > कुंडली लॉन्चर में जाएँ।';
		}
		if ( count( $upd ) > 1 ) {
			wp_update_post( $upd );
		}
	}
	update_option( 'vkl_lang', 'hi' );
}

/* ---------------------------------------------------------------
 * Floating button (front end)
 * ------------------------------------------------------------- */

function vkl_should_show() {
	$o = vkl_opts();
	if ( empty( $o['enabled'] ) || is_admin() || is_feed() || is_embed() ) {
		return false;
	}
	$id = vkl_tool_page_id();
	if ( ! $id || 'publish' !== get_post_status( $id ) ) {
		return false;
	}
	if ( is_page( $id ) ) {
		return false;
	}
	return true;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! vkl_should_show() ) {
		return;
	}
	$o = vkl_opts();
	wp_enqueue_style( 'vkl', VKL_URL . 'assets/launcher.css', array(), VKL_VERSION );
	wp_enqueue_script( 'vkl', VKL_URL . 'assets/launcher.js', array(), VKL_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script(
		'vkl',
		'window.VKL=' . wp_json_encode(
			array(
				'delay'  => max( 0, (int) $o['delay'] ) * 1000,
				'hours'  => max( 1, (int) $o['hours'] ),
				'rotate' => 3600,
			)
		) . ';',
		'before'
	);
} );

add_action( 'wp_footer', function () {
	if ( ! vkl_should_show() ) {
		return;
	}
	$o     = vkl_opts();
	$lines = vkl_parse_lines( $o['lines'] );
	if ( ! $lines ) {
		return;
	}
	$url   = get_permalink( vkl_tool_page_id() );
	$side  = ( 'left' === $o['position'] ) ? 'left' : 'right';
	$label = $lines[0][1] . '. ' . $o['subline'];

	if ( $o['logo_url'] ) {
		$logo = '<img src="' . esc_url( $o['logo_url'] ) . '" alt="" width="52" height="52" loading="lazy" decoding="async">';
	} else {
		$logo = '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="4" width="24" height="24" rx="1.5"/><path d="M4 4l24 24M28 4L4 28"/><path d="M16 4l12 12-12 12L4 16z" fill="rgba(255,255,255,.12)"/><circle cx="16" cy="16" r="2.4" fill="currentColor" stroke="none"/></svg>';
	}
	?>
	<div id="vkl" class="vkl vkl--<?php echo esc_attr( $side ); ?>" hidden>
		<a class="vkl__link" href="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( $label ); ?>">
			<span class="vkl__logo" aria-hidden="true"><?php echo $logo; // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="vkl__badge">मुफ़्त</span></span>
			<span class="vkl__body" aria-hidden="true">
				<span class="vkl__text">
					<span class="vkl__slides">
						<?php foreach ( $lines as $n => $l ) : ?>
							<span class="vkl__slide<?php echo 0 === $n ? ' is-on' : ''; ?>"><span class="vkl__ico"><?php echo vkl_icon( $l[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span><span><?php echo esc_html( $l[1] ); ?></span></span>
						<?php endforeach; ?>
					</span>
					<span class="vkl__sub"><?php echo esc_html( $o['subline'] ); ?></span>
				</span>
				<span class="vkl__go"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" focusable="false"><path d="M9 5l7 7-7 7"/></svg></span>
			</span>
		</a>
		<button type="button" class="vkl__close" aria-label="इस बटन को <?php echo (int) $o['hours']; ?> घंटे के लिए छिपाएँ">
			<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg>
		</button>
	</div>
	<?php
} );

/* ---------------------------------------------------------------
 * Settings page
 * ------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'कुंडली लॉन्चर', 'कुंडली लॉन्चर', 'manage_options', 'vkl-settings', 'vkl_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'vkl_group', 'vkl_options', array( 'sanitize_callback' => 'vkl_sanitize' ) );
} );

function vkl_sanitize( $in ) {
	$d   = vkl_defaults();
	$out = array();
	$out['enabled']  = empty( $in['enabled'] ) ? 0 : 1;
	$out['slug']     = sanitize_title( isset( $in['slug'] ) ? $in['slug'] : $d['slug'] );
	if ( '' === $out['slug'] ) {
		$out['slug'] = $d['slug'];
	}
	$out['title']    = sanitize_text_field( isset( $in['title'] ) ? $in['title'] : $d['title'] );
	$out['position'] = ( isset( $in['position'] ) && 'left' === $in['position'] ) ? 'left' : 'right';
	$out['delay']    = min( 60, max( 0, (int) ( isset( $in['delay'] ) ? $in['delay'] : $d['delay'] ) ) );
	$out['hours']    = min( 720, max( 1, (int) ( isset( $in['hours'] ) ? $in['hours'] : $d['hours'] ) ) );
	$out['logo_url'] = isset( $in['logo_url'] ) ? esc_url_raw( $in['logo_url'] ) : '';
	$out['subline']  = sanitize_text_field( isset( $in['subline'] ) ? $in['subline'] : $d['subline'] );
	$out['lines']    = sanitize_textarea_field( isset( $in['lines'] ) ? $in['lines'] : $d['lines'] );

	$id = vkl_tool_page_id();
	if ( $id && get_post( $id ) ) {
		wp_update_post( array( 'ID' => $id, 'post_name' => $out['slug'], 'post_title' => $out['title'], 'post_status' => 'publish' ) );
	}
	return $out;
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'settings_page_vkl-settings' === $hook ) {
		wp_enqueue_media();
	}
} );

function vkl_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	vkl_ensure_page();
	$o   = vkl_opts();
	$url = vkl_tool_page_id() ? get_permalink( vkl_tool_page_id() ) : '';
	?>
	<div class="wrap">
		<h1>कुंडली लॉन्चर</h1>
		<?php if ( $url ) : ?>
			<p>आपका टूल पेज: <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $url ); ?></a></p>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'vkl_group' ); ?>
			<table class="form-table" role="presentation">
				<tr><th>तैरता हुआ बटन</th><td><label><input type="checkbox" name="vkl_options[enabled]" value="1" <?php checked( $o['enabled'] ); ?>> हर पोस्ट और पेज पर दिखाएँ</label></td></tr>
				<tr><th><label for="vkl_title">पेज का शीर्षक</label></th><td><input id="vkl_title" class="regular-text" name="vkl_options[title]" value="<?php echo esc_attr( $o['title'] ); ?>"></td></tr>
				<tr><th><label for="vkl_slug">पेज का URL स्लग</label></th><td><code><?php echo esc_html( trailingslashit( home_url() ) ); ?></code><input id="vkl_slug" name="vkl_options[slug]" value="<?php echo esc_attr( $o['slug'] ); ?>">
					<p class="description">सुझाव: URL के लिए अंग्रेज़ी अक्षरों वाला छोटा स्लग (जैसे <code>kundli</code>) सबसे भरोसेमंद रहता है।</p></td></tr>
				<tr><th><label for="vkl_lines">घूमती हुई पंक्तियाँ</label></th><td>
					<textarea id="vkl_lines" name="vkl_options[lines]" rows="6" class="large-text code"><?php echo esc_textarea( $o['lines'] ); ?></textarea>
					<p class="description">हर संदेश के लिए एक पंक्ति, अधिकतम 6। पाइप चिह्न (|) से पहले आइकन का नाम देना वैकल्पिक है: <code>sparkle</code> (चमक), <code>heart</code> (दिल), <code>briefcase</code> (करियर), <code>clock</code> (घड़ी), <code>moon</code> (चाँद), <code>chat</code> (संदेश)। उदाहरण: <code>heart|आपकी कुंडली प्रेम पर क्या कहती है?</code></p></td></tr>
				<tr><th><label for="vkl_sub">नीचे की छोटी पंक्ति</label></th><td><input id="vkl_sub" class="regular-text" name="vkl_options[subline]" value="<?php echo esc_attr( $o['subline'] ); ?>"></td></tr>
				<tr><th>लोगो</th><td>
					<input id="vkl_logo" class="regular-text" name="vkl_options[logo_url]" value="<?php echo esc_attr( $o['logo_url'] ); ?>" placeholder="खाली छोड़ें तो बिल्ट-इन कुंडली आइकन दिखेगा">
					<button type="button" class="button" id="vkl_pick">छवि चुनें</button>
					<p class="description">वर्गाकार छवि, कम से कम 104 x 104 px।</p></td></tr>
				<tr><th>स्थिति</th><td>
					<label><input type="radio" name="vkl_options[position]" value="right" <?php checked( $o['position'], 'right' ); ?>> नीचे दाएँ</label>
					&nbsp; <label><input type="radio" name="vkl_options[position]" value="left" <?php checked( $o['position'], 'left' ); ?>> नीचे बाएँ</label></td></tr>
				<tr><th><label for="vkl_delay">इतने सेकंड बाद दिखाएँ</label></th><td><input id="vkl_delay" type="number" min="0" max="60" name="vkl_options[delay]" value="<?php echo (int) $o['delay']; ?>"></td></tr>
				<tr><th><label for="vkl_hours">बंद करने पर इतने घंटे छिपाएँ</label></th><td><input id="vkl_hours" type="number" min="1" max="720" name="vkl_options[hours]" value="<?php echo (int) $o['hours']; ?>"></td></tr>
			</table>
			<?php submit_button( 'बदलाव सहेजें' ); ?>
			<p><button type="button" class="button" id="vkl_reset">इस ब्राउज़र में बटन फिर से दिखाएँ</button> <span id="vkl_reset_msg"></span></p>
		</form>
	</div>
	<script>
	(function(){
		var pick=document.getElementById('vkl_pick');
		if(pick&&window.wp&&wp.media){var f;pick.addEventListener('click',function(){
			if(!f){f=wp.media({title:'लोगो चुनें',multiple:false,library:{type:'image'}});
			f.on('select',function(){document.getElementById('vkl_logo').value=f.state().get('selection').first().toJSON().url;});}
			f.open();});}
		document.getElementById('vkl_reset').addEventListener('click',function(){
			try{localStorage.removeItem('vkl_hide_until');}catch(e){}
			document.cookie='vkl_hide_until=;path=/;max-age=0';
			document.getElementById('vkl_reset_msg').textContent='हो गया। अपनी साइट खोलकर देखें।';
		});
	})();
	</script>
	<?php
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=vkl-settings' ) ) . '">सेटिंग्स</a>' );
	return $links;
} );
