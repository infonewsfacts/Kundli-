<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
$id = (int) get_option( 'vkl_page_id' );
if ( $id ) {
	wp_delete_post( $id, true );
}
delete_option( 'vkl_page_id' );
delete_option( 'vkl_options' );
delete_option( 'vkl_lang' );
